dd=$1
awk 'BEGIN {FS="|"}
{
	if($1=="'"$dd"'"){
		s +=1
		printf "%s %s %s %s %s",$1,$6,$4,$7,$3 
	}

}
END {if (s == 0) printf "�ֶ���ddtbl.txt���Ҳ���!!"} ' $HOME/dict/ddtbl.txt

#END {if (s == 0) printf "%s\t0\tW\t0\n","'"$dd"'"} ' $HOME/dict/ddtbl.txt